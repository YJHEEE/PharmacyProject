package carrot.service;

import java.sql.Connection;
import java.util.ArrayList;
import static carrot.common.jdbc.JDBCTemplate.close;
import static carrot.common.jdbc.JDBCTemplate.getConnection;

import carrot.dao.SearchPhamDao;
import carrot.vo.SearchPham;

public class SearchPhamService {
	private SearchPhamDao dao = new SearchPhamDao();
	
	public ArrayList<SearchPham> searchPhamLists(String name, String gu){
		Connection connection = getConnection();
		ArrayList<SearchPham> list = dao.searchPhamList(connection, name, gu);
		close(connection);
		
		return list;
	}
	public static void main(String[] args) {
		SearchPhamService service = new SearchPhamService();
		ArrayList<SearchPham> list = service.searchPhamLists("약국", "강남구");
		System.out.println(list);
	}
}
