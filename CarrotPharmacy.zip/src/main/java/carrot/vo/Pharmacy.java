package carrot.vo;

public class Pharmacy {
	private String pham_no;	
	private String pham_name;	
	private String pham_tell;	
	private String pham_s_1;
	private String pham_c_1;
	private String pham_s_2;
	private String pham_c_2;
	private String pham_s_3;
	private String pham_c_3;
	private String pham_s_4;
	private String pham_c_4;
	private String pham_s_5;
	private String pham_c_5;
	private String pham_s_6;
	private String pham_c_6;
	private String pham_s_7;
	private String pham_c_7;
	private String pham_s_8	;
	private String pham_c_8;
	
	public Pharmacy() {
		super();
	}

	public Pharmacy(String pham_no, String pham_name, String pham_tell, String pham_s_1, String pham_c_1,
			String pham_s_2, String pham_c_2, String pham_s_3, String pham_c_3, String pham_s_4, String pham_c_4,
			String pham_s_5, String pham_c_5, String pham_s_6, String pham_c_6, String pham_s_7, String pham_c_7,
			String pham_s_8, String pham_c_8) {
		super();
		this.pham_no = pham_no;
		this.pham_name = pham_name;
		this.pham_tell = pham_tell;
		this.pham_s_1 = pham_s_1;
		this.pham_c_1 = pham_c_1;
		this.pham_s_2 = pham_s_2;
		this.pham_c_2 = pham_c_2;
		this.pham_s_3 = pham_s_3;
		this.pham_c_3 = pham_c_3;
		this.pham_s_4 = pham_s_4;
		this.pham_c_4 = pham_c_4;
		this.pham_s_5 = pham_s_5;
		this.pham_c_5 = pham_c_5;
		this.pham_s_6 = pham_s_6;
		this.pham_c_6 = pham_c_6;
		this.pham_s_7 = pham_s_7;
		this.pham_c_7 = pham_c_7;
		this.pham_s_8 = pham_s_8;
		this.pham_c_8 = pham_c_8;
	}

	public String getPham_no() {
		return pham_no;
	}

	public void setPham_no(String pham_no) {
		this.pham_no = pham_no;
	}

	public String getPham_name() {
		return pham_name;
	}

	public void setPham_name(String pham_name) {
		this.pham_name = pham_name;
	}

	public String getPham_tell() {
		return pham_tell;
	}

	public void setPham_tell(String pham_tell) {
		this.pham_tell = pham_tell;
	}

	public String getPham_s_1() {
		return pham_s_1;
	}

	public void setPham_s_1(String pham_s_1) {
		this.pham_s_1 = pham_s_1;
	}

	public String getPham_c_1() {
		return pham_c_1;
	}

	public void setPham_c_1(String pham_c_1) {
		this.pham_c_1 = pham_c_1;
	}

	public String getPham_s_2() {
		return pham_s_2;
	}

	public void setPham_s_2(String pham_s_2) {
		this.pham_s_2 = pham_s_2;
	}

	public String getPham_c_2() {
		return pham_c_2;
	}

	public void setPham_c_2(String pham_c_2) {
		this.pham_c_2 = pham_c_2;
	}

	public String getPham_s_3() {
		return pham_s_3;
	}

	public void setPham_s_3(String pham_s_3) {
		this.pham_s_3 = pham_s_3;
	}

	public String getPham_c_3() {
		return pham_c_3;
	}

	public void setPham_c_3(String pham_c_3) {
		this.pham_c_3 = pham_c_3;
	}

	public String getPham_s_4() {
		return pham_s_4;
	}

	public void setPham_s_4(String pham_s_4) {
		this.pham_s_4 = pham_s_4;
	}

	public String getPham_c_4() {
		return pham_c_4;
	}

	public void setPham_c_4(String pham_c_4) {
		this.pham_c_4 = pham_c_4;
	}

	public String getPham_s_5() {
		return pham_s_5;
	}

	public void setPham_s_5(String pham_s_5) {
		this.pham_s_5 = pham_s_5;
	}

	public String getPham_c_5() {
		return pham_c_5;
	}

	public void setPham_c_5(String pham_c_5) {
		this.pham_c_5 = pham_c_5;
	}

	public String getPham_s_6() {
		return pham_s_6;
	}

	public void setPham_s_6(String pham_s_6) {
		this.pham_s_6 = pham_s_6;
	}

	public String getPham_c_6() {
		return pham_c_6;
	}

	public void setPham_c_6(String pham_c_6) {
		this.pham_c_6 = pham_c_6;
	}

	public String getPham_s_7() {
		return pham_s_7;
	}

	public void setPham_s_7(String pham_s_7) {
		this.pham_s_7 = pham_s_7;
	}

	public String getPham_c_7() {
		return pham_c_7;
	}

	public void setPham_c_7(String pham_c_7) {
		this.pham_c_7 = pham_c_7;
	}

	public String getPham_s_8() {
		return pham_s_8;
	}

	public void setPham_s_8(String pham_s_8) {
		this.pham_s_8 = pham_s_8;
	}

	public String getPham_c_8() {
		return pham_c_8;
	}

	public void setPham_c_8(String pham_c_8) {
		this.pham_c_8 = pham_c_8;
	}

	@Override
	public String toString() {
		return "PHARMACY [pham_no=" + pham_no + ", pham_name=" + pham_name + ", pham_tell=" + pham_tell + ", pham_s_1="
				+ pham_s_1 + ", pham_c_1=" + pham_c_1 + ", pham_s_2=" + pham_s_2 + ", pham_c_2=" + pham_c_2
				+ ", pham_s_3=" + pham_s_3 + ", pham_c_3=" + pham_c_3 + ", pham_s_4=" + pham_s_4 + ", pham_c_4="
				+ pham_c_4 + ", pham_s_5=" + pham_s_5 + ", pham_c_5=" + pham_c_5 + ", pham_s_6=" + pham_s_6
				+ ", pham_c_6=" + pham_c_6 + ", pham_s_7=" + pham_s_7 + ", pham_c_7=" + pham_c_7 + ", pham_s_8="
				+ pham_s_8 + ", pham_c_8=" + pham_c_8 + "]";
	}	
}
